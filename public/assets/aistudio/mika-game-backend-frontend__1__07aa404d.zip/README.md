# Mika Games

Separated frontend and PostgreSQL backend. MongoDB and JSON state-file persistence have been removed from this package.

## Requirements
- Node.js 20+
- PostgreSQL 14+

## Backend
1. `cd backend && npm install`
2. Copy `.env.example` to `.env` and configure PostgreSQL/session secrets.
3. Apply `database/migrations/001_initial.sql` to your database.
4. `npm run seed` inserts demo data only when the relevant tables are empty. Demo password in the seed is `password`; change/remove demo accounts before deployment.
5. `npm run dev`

## Frontend
1. `cd frontend && npm install`
2. Configure the frontend API base URL in the frontend API client if needed.
3. `npm run dev` or `npm run build`.

## Important
The supplied source contains a PostgreSQL secure API and an existing React UI. This package separates them and removes the legacy MongoDB/Vite Express state server. The backend's feature folders are modular boundaries; not every legacy UI workflow has yet been migrated to PostgreSQL endpoints. Verify each screen/API workflow in your test environment before production. Preserve your actual commission configuration and validate the SoftSwiss callback integration against provider documentation and test credentials.
