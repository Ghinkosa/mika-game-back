import { useCallback, useEffect, useState } from "react";
import type { SystemState } from "../types";

interface StateResponse {
  state?: SystemState;
  data?: SystemState;
  [key: string]: unknown;
}

async function requestSystemState(
  url: string,
  options?: RequestInit,
): Promise<unknown> {
  const response = await fetch(url, {
    credentials: "include",
    cache: "no-store",
    ...options,
    headers: {
      Accept: "application/json",
      ...(options?.body ? { "Content-Type": "application/json" } : {}),
      ...options?.headers,
    },
  });

  const contentType = response.headers.get("content-type") ?? "";
  const body = contentType.includes("application/json")
    ? await response.json()
    : await response.text();

  if (!response.ok) {
    const message =
      typeof body === "object" &&
      body !== null &&
      "message" in body &&
      typeof body.message === "string"
        ? body.message
        : `Request failed (${response.status})`;

    throw new Error(message);
  }

  return body;
}

function extractState(result: unknown): SystemState {
  if (!result || typeof result !== "object") {
    throw new Error("The server returned an invalid system state.");
  }

  const response = result as StateResponse;

  // Supports either { state: ... }, { data: ... }, or a direct state object.
  const candidate = response.state ?? response.data ?? result;

  if (
    !candidate ||
    typeof candidate !== "object" ||
    !Array.isArray((candidate as SystemState).accounts)
  ) {
    throw new Error(
      "The /api/state response must contain a system state with an accounts array.",
    );
  }

  return candidate as SystemState;
}

export function useSystemState() {
  const [state, setState] = useState<SystemState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadState = useCallback(async (): Promise<void> => {
    setLoading(true);
    setError(null);

    try {
      const result = await requestSystemState("/api/state");
      setState(extractState(result));
    } catch (err) {
      const message =
        err instanceof Error
          ? err.message
          : "Unable to load system state.";

      setError(message);
    } finally {
      setLoading(false);
    }
  }, []);

  const updateState = useCallback(
    async (newState: SystemState): Promise<void> => {
      const result = await requestSystemState("/api/state", {
        method: "POST",
        body: JSON.stringify(newState),
      });

      // If the server returns the saved state, use it.
      // Otherwise, use the state that was submitted.
      let savedState: SystemState;

      try {
        savedState = extractState(result);
      } catch {
        savedState = newState;
      }

      setState(savedState);
    },
    [],
  );

  useEffect(() => {
    void loadState();
  }, [loadState]);

  return {
    state,
    loading,
    error,
    loadState,
    refresh: loadState,
    updateState,
  };
}