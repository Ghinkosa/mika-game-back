
import { useCallback, useEffect, useMemo, useState } from "react";
import type { Account } from "../types";
import { apiRequest, setCsrfToken } from "../services/apiClient";

interface AuthUserResponse {
  id: string;
  username: string;
  displayName?: string;
  display_name?: string;
  role: string;
  status: string;
  parentId?: string | null;
  parent_id?: string | null;
}

interface AuthResponse {
  success?: boolean;
  user?: AuthUserResponse;
  account?: AuthUserResponse;
  csrfToken?: string;
  error?: string;
  message?: string;
}

interface LoginCredentials {
  username: string;
  password: string;
}

export function useAuth(accounts: Account[] = []) {
  const [authUser, setAuthUser] = useState<AuthUserResponse | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(true);

  const loadSession = useCallback(async () => {
    setLoadingAuth(true);

    try {
      const result = await apiRequest<AuthResponse>("/api/auth/me");
      const user = result.user ?? result.account;

      if (!user) {
        setAuthUser(null);
        return null;
      }

      setAuthUser(user);
      return user;
    } catch {
      setAuthUser(null);
      return null;
    } finally {
      setLoadingAuth(false);
    }
  }, []);

  useEffect(() => {
    void loadSession();
  }, [loadSession]);

  const login = useCallback(
    async (credentials: LoginCredentials) => {
      const result = await apiRequest<AuthResponse>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(credentials),
      });

      const user = result.user ?? result.account;

      if (!user) {
        throw new Error(
          result.error ?? result.message ?? "Login response did not contain a user."
        );
      }

      if (result.csrfToken) {
        setCsrfToken(result.csrfToken);
      }

      setAuthUser(user);
      return user;
    },
    []
  );

  const logout = useCallback(async () => {
    try {
      await apiRequest("/api/auth/logout", { method: "POST" });
    } finally {
      setAuthUser(null);
      setCsrfToken(null);
    }
  }, []);

  const account = useMemo(() => {
    if (!authUser) return null;

    // Backend UUIDs should match the IDs loaded from the backend.
    return (
      accounts.find((item) => item.id === authUser.id) ??
      ({
        id: authUser.id,
        username: authUser.username,
        displayName:
          authUser.displayName ??
          authUser.display_name ??
          authUser.username,
        role: authUser.role,
        status: authUser.status,
        parentId: authUser.parentId ?? authUser.parent_id ?? null,
      } as unknown as Account)
    );
  }, [accounts, authUser]);

  return {
    account,
    accountId: authUser?.id ?? null,
    isAuthenticated: authUser !== null,
    loadingAuth,
    login,
    logout,
    loadSession,
  };
}
