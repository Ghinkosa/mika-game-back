import { Navigate, Outlet, useLocation } from "react-router-dom";
import type { UserRole } from "../types";

interface ProtectedRouteProps {
  accountRole?: UserRole | null;
  allowedRoles: UserRole[];
}

export default function ProtectedRoute({
  accountRole,
  allowedRoles,
}: ProtectedRouteProps) {
  const location = useLocation();

  if (!accountRole) {
    return (
      <Navigate
        to="/"
        replace
        state={{ from: location.pathname }}
      />
    );
  }

  if (!allowedRoles.includes(accountRole)) {
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
}
