import {
  Navigate,
  Route,
  Routes,
  useNavigate,
} from "react-router-dom";

import type { Account, SystemState, UserRole } from "../types";

import LandingPage from "../pages/LandingPage";
import PlayerLoginPage from "../pages/PlayerLoginPage";
import PlayerRegistrationPage from "../pages/PlayerRegistrationPage";
import StaffLoginPage from "../pages/StaffLoginPage";

import AdminPage from "../pages/AdminPage";
import SuperAgentPage from "../pages/SuperAgentPage";
import AgentPage from "../pages/AgentPage";
import PlayerPage from "../pages/PlayerPage";

import ProtectedRoute from "./ProtectedRoute";
import AppLayout from "../components/layout/AppLayout";

interface Props {
  state: SystemState | null;
  account: Account | null;
  onLogin: (account: Account) => void;
  onLogout: () => void;
  onStateUpdate: (state: SystemState) => void;
}

const destinations: Record<UserRole, string> = {
  ADMIN: "/admin",
  SUPER_AGENT: "/super-agent",
  AGENT: "/agent",
  PLAYER: "/player",
};

function LoadingScreen() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#080d17] text-white">
      <div className="text-center">
        <div className="mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-4 border-white/10 border-t-[#38b6ff]" />
        <p className="text-sm text-slate-400">
          Loading Mika Games...
        </p>
      </div>
    </div>
  );
}

export default function AppRoutes({
  state,
  account,
  onLogin,
  onLogout,
  onStateUpdate,
}: Props) {
  const navigate = useNavigate();

  const handlePlayerLogin = (user: Account) => {
    if (user.role !== "PLAYER") {
      window.alert("Please use a player account.");
      return;
    }

    onLogin(user);
    navigate(destinations.PLAYER, { replace: true });
  };

  const handleStaffLogin = (user: Account) => {
    const staffRoles: UserRole[] = [
      "ADMIN",
      "SUPER_AGENT",
      "AGENT",
    ];

    if (!staffRoles.includes(user.role)) {
      window.alert("Please use a staff account.");
      return;
    }

    onLogin(user);
    navigate(destinations[user.role], { replace: true });
  };

  const handleLogout = () => {
    onLogout();
    navigate("/", { replace: true });
  };

  return (
    <Routes>
      {/* Public landing page */}
      <Route
        path="/"
        element={
          account ? (
            <Navigate
              to={destinations[account.role]}
              replace
            />
          ) : (
            <LandingPage
              onPlayerLogin={() => navigate("/player/login")}
              onPlayerRegister={() => navigate("/player/register")}
            />
          )
        }
      />

      {/* Public player login */}
      <Route
        path="/player/login"
        element={
          account ? (
            <Navigate
              to={destinations[account.role]}
              replace
            />
          ) : state ? (
            <PlayerLoginPage
              state={state}
              onLoginSuccess={handlePlayerLogin}
              onStateUpdate={onStateUpdate}
            />
          ) : (
            <LoadingScreen />
          )
        }
      />

      {/* Public player registration */}
      <Route
        path="/player/register"
        element={
          account ? (
            <Navigate
              to={destinations[account.role]}
              replace
            />
          ) : state ? (
            <PlayerRegistrationPage
              state={state}
              onStateUpdate={onStateUpdate}
            />
          ) : (
            <LoadingScreen />
          )
        }
      />

      {/* Public staff login */}
      <Route
        path="/management/login"
        element={
          account ? (
            <Navigate
              to={destinations[account.role]}
              replace
            />
          ) : (
            <StaffLoginPage
              onLoginSuccess={handleStaffLogin}
            />
          )
        }
      />

      {/* Protected admin dashboard */}
      <Route
        element={
          <ProtectedRoute
            accountRole={account?.role}
            allowedRoles={["ADMIN"]}
          />
        }
      >
        <Route
          path="/admin"
          element={
            state && account?.role === "ADMIN" ? (
              <AppLayout
                account={account}
                onLogout={handleLogout}
              >
                <AdminPage
                  state={state}
                  onStateUpdate={onStateUpdate}
                />
              </AppLayout>
            ) : (
              <LoadingScreen />
            )
          }
        />
      </Route>

      {/* Protected super-agent dashboard */}
      <Route
        element={
          <ProtectedRoute
            accountRole={account?.role}
            allowedRoles={["SUPER_AGENT"]}
          />
        }
      >
        <Route
          path="/super-agent"
          element={
            state && account?.role === "SUPER_AGENT" ? (
              <AppLayout
                account={account}
                onLogout={handleLogout}
              >
                <SuperAgentPage
                  state={state}
                  superAgentId={account.id}
                  onStateUpdate={onStateUpdate}
                />
              </AppLayout>
            ) : (
              <LoadingScreen />
            )
          }
        />
      </Route>

      {/* Protected agent dashboard */}
      <Route
        element={
          <ProtectedRoute
            accountRole={account?.role}
            allowedRoles={["AGENT"]}
          />
        }
      >
        <Route
          path="/agent"
          element={
            state && account?.role === "AGENT" ? (
              <AppLayout
                account={account}
                onLogout={handleLogout}
              >
                <AgentPage
                  state={state}
                  agentId={account.id}
                  onStateUpdate={onStateUpdate}
                />
              </AppLayout>
            ) : (
              <LoadingScreen />
            )
          }
        />
      </Route>

      {/* Protected player dashboard */}
      <Route
        element={
          <ProtectedRoute
            accountRole={account?.role}
            allowedRoles={["PLAYER"]}
          />
        }
      >
        <Route
          path="/player"
          element={
            state && account?.role === "PLAYER" ? (
              <AppLayout
                account={account}
                onLogout={handleLogout}
              >
                <PlayerPage
                  state={state}
                  playerId={account.id}
                  onStateUpdate={onStateUpdate}
                />
              </AppLayout>
            ) : (
              <LoadingScreen />
            )
          }
        />
      </Route>

      {/* Unknown routes */}
      <Route
        path="*"
        element={<Navigate to="/" replace />}
      />
    </Routes>
  );
}