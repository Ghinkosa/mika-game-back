
import { apiRequest, setCsrfToken } from "./apiClient";

export interface AuthUser {
  id: string;
  username: string;
  displayName: string;
  role: "ADMIN" | "SUPER_AGENT" | "AGENT" | "PLAYER";
  status: string;
}

interface LoginResponse {
  user: AuthUser;
  csrfToken: string;
}

interface MeResponse {
  user: {
    id: string;
    username: string;
    display_name: string;
    role: AuthUser["role"];
    status: string;
  };
}

interface RegistrationResponse {
  user?: AuthUser;
  csrfToken?: string;
  message?: string;
}

export async function registerUser(data: {
  username: string;
  displayName: string;
  password: string;
  phoneNumber: string;
  cbeAccount?: string;
  agentId?: string;
}): Promise<RegistrationResponse> {
  const result = await apiRequest<RegistrationResponse>(
    "/api/auth/register",
    {
      method: "POST",
      body: JSON.stringify(data),
    }
  );

  if (result.csrfToken) {
    setCsrfToken(result.csrfToken);
  }

  return result;
}

export async function loginUser(
  username: string,
  password: string
): Promise<AuthUser> {
  const result = await apiRequest<LoginResponse>(
    "/api/auth/login",
    {
      method: "POST",
      body: JSON.stringify({ username, password }),
    }
  );

  if (result.csrfToken) {
    setCsrfToken(result.csrfToken);
  }

  return result.user;
}

export async function getCurrentUser(): Promise<AuthUser> {
  const result = await apiRequest<MeResponse>("/api/auth/me");

  return {
    id: result.user.id,
    username: result.user.username,
    displayName: result.user.display_name,
    role: result.user.role,
    status: result.user.status,
  };
}

export async function logoutUser(): Promise<void> {
  await apiRequest<void>("/api/auth/logout", {
    method: "POST",
  });

  setCsrfToken(null);
}
