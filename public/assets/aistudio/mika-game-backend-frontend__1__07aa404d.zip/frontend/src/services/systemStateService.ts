
import { apiRequest } from "./apiClient";
import type { AuthUser } from "./auth";

interface BackendAccount {
  id: string;
  username: string;
  display_name: string;
  role: AuthUser["role"];
  status: string;
  parent_id: string | null;
  phone_number?: string | null;
  commission_rate?: number | string;
  created_at: string;
  balance_minor?: number | string;
  currency?: string;
}

export async function fetchMyAccount(): Promise<BackendAccount> {
  return apiRequest<BackendAccount>("/api/accounts/me");
}

export async function fetchAccounts(): Promise<BackendAccount[]> {
  return apiRequest<BackendAccount[]>("/api/accounts");
}
