
const API_BASE_URL = (
  import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8080"
).replace(/\/+$/, "");

let csrfToken: string | null = null;
let csrfRequest: Promise<string> | null = null;

interface ApiErrorResponse {
  error?: string;
  message?: string;
}

interface CsrfResponse {
  csrfToken: string;
}

export function setCsrfToken(token: string | null): void {
  csrfToken = token;
}

async function getCsrfToken(): Promise<string> {
  if (csrfToken) return csrfToken;

  // Avoid simultaneous requests for multiple CSRF tokens.
  if (!csrfRequest) {
    csrfRequest = (async () => {
      const response = await fetch(`${API_BASE_URL}/api/auth/csrf`, {
        method: "GET",
        credentials: "include",
        headers: { Accept: "application/json" },
      });

      const data: CsrfResponse | null = await response
        .json()
        .catch(() => null);

      if (!response.ok || !data?.csrfToken) {
        throw new Error("Unable to initialize security token.");
      }

      csrfToken = data.csrfToken;
      return data.csrfToken;
    })().finally(() => {
      csrfRequest = null;
    });
  }

  return csrfRequest;
}

export async function apiRequest<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const method = (options.method ?? "GET").toUpperCase();
  const headers = new Headers(options.headers);

  headers.set("Accept", "application/json");

  if (options.body !== undefined && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  const requiresCsrf = !["GET", "HEAD", "OPTIONS"].includes(method);

  if (requiresCsrf) {
    headers.set("X-CSRF-Token", await getCsrfToken());
  }

  let response: Response;

  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      ...options,
      method,
      headers,
      credentials: "include",
    });
  } catch {
    throw new Error(
      `Cannot connect to the backend at ${API_BASE_URL}. Check that the server is running and CORS is configured.`
    );
  }

  const contentType = response.headers.get("content-type") ?? "";
  const data: unknown = contentType.includes("application/json")
    ? await response.json().catch(() => null)
    : await response.text().catch(() => "");

  if (!response.ok) {
  const errorData = data as ApiErrorResponse | null;

  throw new Error(
    errorData?.error ||
      errorData?.message ||
      (typeof data === "string" && data) ||
      `Request failed with status ${response.status}`
  );
}

  // Do not clear the CSRF token just because logout succeeded.
  // Clear it when the server indicates the session is no longer valid.
  const result = data as T & Partial<CsrfResponse>;

  if (
    (path === "/api/auth/login" || path === "/api/auth/me") &&
    result?.csrfToken
  ) {
    csrfToken = result.csrfToken;
  }

  if (path === "/api/auth/logout") {
    csrfToken = null;
  }

  return data as T;
}
