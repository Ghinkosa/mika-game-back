import { BrowserRouter, useNavigate } from "react-router-dom";
import { AlertCircle, RefreshCw, Loader2 } from "lucide-react";

import { useAuth } from "./hooks/useAuth";
import { useSystemState } from "./hooks/useSystemState";
import AppRoutes from "./routes/AppRoutes";

function LoadingScreen() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-[#06101b] text-white">
      <div className="flex flex-col items-center gap-3">
        <Loader2 className="animate-spin text-[#38b6ff]" size={36} />
        <p className="text-sm text-slate-300">Loading Mika Games...</p>
      </div>
    </main>
  );
}

function StateError({
  message,
  onRetry,
}: {
  message: string;
  onRetry: () => void;
}) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-[#06101b] px-4 text-white">
      <div className="w-full max-w-md rounded-2xl border border-white/10 bg-[#111b2b] p-6">
        <div className="mb-4 flex items-center gap-3">
          <AlertCircle className="text-red-400" size={28} />
          <h1 className="text-xl font-bold">Unable to load the application</h1>
        </div>

        <p className="mb-6 break-words text-sm text-slate-300">{message}</p>

        <button
          type="button"
          onClick={onRetry}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#38b6ff] px-4 py-3 font-bold text-[#06101b] hover:bg-sky-300"
        >
          <RefreshCw size={18} />
          Try again
        </button>
      </div>
    </main>
  );
}

function AppContent() {
  const { state, loading, error, updateState, loadState } =
    useSystemState();

  const { account, login, logout } = useAuth(state?.accounts ?? []);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/", { replace: true });
  };

  const handleStateUpdate = (newState: NonNullable<typeof state>) => {
    void updateState(newState).catch((err: unknown) => {
      console.error("Failed to update system state:", err);
    });
  };

  if (loading && !state) {
    return <LoadingScreen />;
  }

  if (!state) {
    return (
      <StateError
        message={error ?? "The system state is unavailable."}
        onRetry={() => {
          void loadState();
        }}
      />
    );
  }

  return (
    <AppRoutes
      state={state}
      account={account}
      onLogin={login}
      onLogout={handleLogout}
      onStateUpdate={handleStateUpdate}
    />
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}