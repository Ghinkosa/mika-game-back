import 'dotenv/config';
import argon2 from 'argon2';
import { pool, transaction } from './db';

// Development/demo bootstrap only. This seeds the supplied demo records only when
// the corresponding PostgreSQL tables are empty. It never overwrites existing rows.
const accounts = [
  { id: 'admin-1', username: 'admin', password: 'password', role: 'ADMIN', displayName: 'Mika Global Admin', balance: 5000000, parentId: null, commissionRate: 100, createdAt: '2026-01-01T00:00:00Z', status: 'active', phoneNumber: '+251911223344', cbeAccount: '1000123456789' },
  { id: 'sa-1', username: 'super_vortex', password: 'password', role: 'SUPER_AGENT', displayName: 'Vortex Elite Distribution', balance: 340500, parentId: 'admin-1', commissionRate: 85, createdAt: '2026-02-15T12:00:00Z', status: 'active', phoneNumber: '+251912345678', cbeAccount: '1000987654321' },
  { id: 'sa-2', username: 'super_apex', password: 'password', role: 'SUPER_AGENT', displayName: 'Apex Global Network', balance: 200000, parentId: 'admin-1', commissionRate: 80, createdAt: '2026-03-01T09:30:00Z', status: 'active', phoneNumber: '+251923456789', cbeAccount: '1000876543210' },
  { id: 'ag-1', username: 'agent_ares', password: 'password', role: 'AGENT', displayName: 'Ares Sports Club', balance: 95000, parentId: 'sa-1', commissionRate: 70, createdAt: '2026-02-20T14:45:00Z', status: 'active', phoneNumber: '+251934567890', cbeAccount: '1000765432109' },
  { id: 'ag-2', username: 'agent_zeus', password: 'password', role: 'AGENT', displayName: 'Zeus Betting Lounge', balance: 50000, parentId: 'sa-1', commissionRate: 65, createdAt: '2026-03-10T11:20:00Z', status: 'active', phoneNumber: '+251945678901', cbeAccount: '1000654321098' },
  { id: 'ag-3', username: 'agent_titan', password: 'password', role: 'AGENT', displayName: 'Titan VIP Slot Club', balance: 90000, parentId: 'sa-2', commissionRate: 72, createdAt: '2026-03-12T16:00:00Z', status: 'active', phoneNumber: '+251956789012', cbeAccount: '1000543210987' },
  { id: 'pl-1', username: 'lucky_spin', password: 'password', role: 'PLAYER', displayName: 'James R. (Lucky Spin)', balance: 3500, parentId: 'ag-1', commissionRate: 0, createdAt: '2026-03-15T18:30:00Z', status: 'active', phoneNumber: '+251967890123', cbeAccount: '1000432109876' },
  { id: 'pl-2', username: 'high_roller', password: 'password', role: 'PLAYER', displayName: 'Sophia K. (VIP Elite)', balance: 15000, parentId: 'ag-3', commissionRate: 0, createdAt: '2026-03-18T10:15:00Z', status: 'active', phoneNumber: '+251978901234', cbeAccount: '1000321098765' },
  { id: 'pl-3', username: 'crash_master', password: 'password', role: 'PLAYER', displayName: 'Erick L. (Crash Pro)', balance: 2100, parentId: 'ag-2', commissionRate: 0, createdAt: '2026-03-20T22:00:00Z', status: 'active', phoneNumber: '+251989012345', cbeAccount: '1000210987654' }
] as const;

const transactions = [
  { id: 'tx-1793280505247-973', senderId: 'sa-1', receiverId: 'ag-1', amount: 10000, timestamp: '2026-10-29T13:28:25.247Z', type: 'transfer', notes: 'Approved Point Deposit Request: test' },
  { id: 'tx-1', senderId: 'admin-1', receiverId: 'sa-1', amount: 350000, timestamp: '2026-02-15T12:05:00Z', type: 'transfer', notes: 'Initial credit distribution allocation for Super Agent' },
  { id: 'tx-2', senderId: 'admin-1', receiverId: 'sa-2', amount: 200000, timestamp: '2026-03-01T09:35:00Z', type: 'transfer', notes: 'Initial credit allocation' },
  { id: 'tx-3', senderId: 'sa-1', receiverId: 'ag-1', amount: 85000, timestamp: '2026-02-20T15:00:00Z', type: 'transfer', notes: 'Agent setup credits allocation' },
  { id: 'tx-4', senderId: 'ag-1', receiverId: 'pl-1', amount: 3500, timestamp: '2026-03-15T19:00:00Z', type: 'deposit', notes: 'Cash in deposit' }
] as const;

async function main() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const usersCount = Number((await client.query('SELECT COUNT(*)::int AS n FROM public.users')).rows[0].n);
    if (usersCount === 0) {
      const ids = new Map<string, string>();
      // Hash the common demo password once; each account receives the same hash.
      const passwordHash = await argon2.hash('password', { type: argon2.argon2id });
      for (const a of accounts) {
        const parentId = a.parentId ? ids.get(a.parentId) : null;
        const result = await client.query(
          `INSERT INTO public.users
             (username, display_name, password_hash, role, status, parent_id, phone_number, cbe_account, commission_rate, created_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
          [a.username, a.displayName, passwordHash, a.role, a.status.toUpperCase(), parentId, a.phoneNumber, a.cbeAccount, a.commissionRate, a.createdAt]
        );
        const userId = result.rows[0].id as string;
        ids.set(a.id, userId);
        await client.query(
          `INSERT INTO public.wallets (user_id, currency, balance_minor, updated_at)
           VALUES ($1, 'ETB', $2, now())`,
          [userId, Math.round(a.balance * 100)]
        );
      }
      console.log(`Seeded ${accounts.length} demo users and wallets.`);
    } else {
      console.log(`Skipped users/wallets seed: users table already contains ${usersCount} row(s).`);
    }

    const txCount = Number((await client.query('SELECT COUNT(*)::int AS n FROM public.ledger_transactions')).rows[0].n);
    if (txCount === 0) {
      const userRows = await client.query('SELECT id, username FROM public.users');
      const byLegacyId = new Map<string, string>();
      const usernameToLegacy = new Map(accounts.map(a => [a.username, a.id]));
      const legacyToUsername = new Map(accounts.map(a => [a.id, a.username]));
      for (const row of userRows.rows) {
        const legacyId = usernameToLegacy.get(row.username);
        if (legacyId) byLegacyId.set(legacyId, row.id);
      }
      const missing = accounts.filter(a => !byLegacyId.has(a.id));
      if (missing.length) throw new Error(`Cannot seed ledger: missing account(s): ${missing.map(a => a.username).join(', ')}. Seed users first or check existing usernames.`);

      for (const t of transactions) {
        const senderUuid = byLegacyId.get(t.senderId);
        const receiverUuid = byLegacyId.get(t.receiverId);
        if (!senderUuid || !receiverUuid) throw new Error(`Missing sender/receiver mapping for ${t.id}`);
        const inserted = await client.query(
          `INSERT INTO public.ledger_transactions
             (transaction_type, status, idempotency_key, reference, description, created_by, created_at)
           VALUES ($1, 'POSTED', $2, $2, $3, $4, $5) RETURNING id`,
          [t.type, `legacy:${t.id}`, t.notes, senderUuid, t.timestamp]
        );
        const transactionId = inserted.rows[0].id;
        const amountMinor = Math.round(t.amount * 100);
        await client.query(
          `INSERT INTO public.ledger_entries (transaction_id, user_id, amount_minor, currency, created_at)
           VALUES ($1,$2,$3,'ETB',$4), ($1,$5,$6,'ETB',$4)`,
          [transactionId, senderUuid, -amountMinor, t.timestamp, receiverUuid, amountMinor]
        );
      }
      console.log(`Seeded ${transactions.length} legacy transactions and ${transactions.length * 2} ledger entries.`);
    } else {
      console.log(`Skipped ledger seed: ledger_transactions table already contains ${txCount} row(s).`);
    }
    await client.query('COMMIT');
    console.log('Seed completed.');
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch(err => { console.error('Seed failed:', err instanceof Error ? err.message : err); process.exitCode = 1; });
