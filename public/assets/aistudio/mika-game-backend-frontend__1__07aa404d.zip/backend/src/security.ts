import crypto from 'node:crypto';
import { Request, Response, NextFunction } from 'express';
import { pool } from './db';

export type Role = 'ADMIN' | 'SUPER_AGENT' | 'AGENT' | 'PLAYER';

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId || !req.session.role) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  next();
}

export function requireRoles(...roles: Role[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.session.userId || !req.session.role) return res.status(401).json({ error: 'Authentication required' });
    if (!roles.includes(req.session.role)) return res.status(403).json({ error: 'Forbidden' });
    next();
  };
}

export function csrfProtection(req: Request, res: Response, next: NextFunction) {
  if (['GET','HEAD','OPTIONS'].includes(req.method)) return next();
  if (!req.session.userId) return next(); // public registration/login use rate limiting and same-origin CORS
  const expected = req.session.csrfToken;
  const supplied = req.header('x-csrf-token');
  if (!expected || !supplied) return res.status(403).json({ error: 'CSRF token required' });
  const a = Buffer.from(expected);
  const b = Buffer.from(supplied);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(403).json({ error: 'Invalid CSRF token' });
  next();
}

export async function audit(req: Request, action: string, targetType?: string, targetId?: string, metadata: Record<string, unknown> = {}) {
  // Only pass deliberately selected, non-sensitive metadata.
  await pool.query(
    `INSERT INTO audit_events (actor_user_id, action, target_type, target_id, ip_address, user_agent, metadata)
     VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)`,
    [req.session.userId ?? null, action, targetType ?? null, targetId ?? null,
      req.ip || null, req.get('user-agent')?.slice(0, 500) ?? null, JSON.stringify(metadata)]
  );
}
