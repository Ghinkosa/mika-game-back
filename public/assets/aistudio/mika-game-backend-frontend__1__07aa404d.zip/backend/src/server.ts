
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import session from 'express-session';
import connectPgSimple from 'connect-pg-simple';
import rateLimit from 'express-rate-limit';
import crypto from 'node:crypto';
import argon2 from 'argon2';
import { z } from 'zod';
import { config, isProduction } from './config';
import { pool, transaction } from './db';
import { audit, csrfProtection, requireAuth, requireRoles } from './security';

const app = express();
const PgSession = connectPgSimple(session);

if (isProduction) app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet());

app.use(cors({
  origin: config.FRONTEND_ORIGIN,
  credentials: true,
  methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'X-CSRF-Token', 'Idempotency-Key']
}));

app.use(express.json({ limit: '32kb' }));

app.use(session({
  name: isProduction ? '__Host-mika.sid' : 'mika.sid',
  store: new PgSession({
    pool,
    tableName: 'session',
    createTableIfMissing: false
  }),
  secret: config.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    secure: isProduction,
    sameSite: 'lax',
    path: '/',
    maxAge: config.SESSION_MAX_AGE_MS
  }
}));

app.use(csrfProtection);

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: 'draft-7',
  legacyHeaders: false
});

const loginSchema = z.object({
  username: z.string().trim().min(3).max(40).transform(v => v.toLowerCase()),
  password: z.string().min(1).max(128)
});

const registerSchema = z.object({
  username: z.string().trim().min(3).max(40)
    .regex(/^[a-zA-Z0-9_.-]+$/)
    .transform(v => v.toLowerCase()),
  displayName: z.string().trim().min(2).max(120),
  password: z.string().min(6).max(128),
  phoneNumber: z.string().trim().max(32).optional()
});

const transferSchema = z.object({
  toUserId: z.string().uuid(),
  amountMinor: z.number().int().positive().max(100000000),
  currency: z.string().length(3).default('ETB'),
  reference: z.string().trim().max(128).optional()
});

const betSchema = z.object({
  amountMinor: z.number().int().positive().max(100000000),
  gameCode: z.string().trim().min(1).max(64),
  externalBetId: z.string().trim().min(1).max(128)
});

app.get('/health', (_req, res) => {
  res.json({ status: 'ok' });
});

/**
 * Initialize the CSRF token for the current session.
 */
app.get('/api/auth/csrf', (req, res) => {
  req.session.csrfToken ??= crypto.randomBytes(32).toString('hex');

  req.session.save(err => {
    if (err) {
      return res.status(500).json({
        error: 'Could not initialize session'
      });
    }

    return res.json({
      csrfToken: req.session.csrfToken
    });
  });
});

/**
 * Public registration endpoint.
 */
/**
 * Public player registration endpoint.
 *
 * New players are automatically approved and activated.
 * No admin approval is required.
 */
app.post('/api/auth/register', authLimiter, async (req, res, next) => {
  try {
    const input = registerSchema.parse(req.body);

    // Hash password using Argon2id.
    const hash = await argon2.hash(input.password, {
      type: argon2.argon2id,
      memoryCost: 19456,
      timeCost: 2,
      parallelism: 1
    });

    // Create player and wallet in one database transaction.
    const user = await transaction(async client => {

      const created = await client.query(
        `INSERT INTO users
          (
            username,
            display_name,
            password_hash,
            role,
            status,
            phone_number
          )
         VALUES ($1, $2, $3, 'PLAYER', 'ACTIVE', $4)
         RETURNING
            id,
            username,
            display_name,
            role,
            status,
            created_at`,
        [
          input.username,
          input.displayName,
          hash,
          input.phoneNumber ?? null
        ]
      );

      // Automatically create the player's ETB wallet.
      await client.query(
        `INSERT INTO wallets
          (user_id, currency, balance_minor)
         VALUES ($1, 'ETB', 0)`,
        [created.rows[0].id]
      );

      return created.rows[0];
    });

    // Record successful registration.
    await audit(req, 'auth.register', 'user', user.id, {
      role: user.role,
      status: user.status,
      autoApproved: true
    });

    return res.status(201).json({
      user: {
        id: user.id,
        username: user.username,
        displayName: user.display_name,
        role: user.role,
        status: user.status,
        createdAt: user.created_at
      },
      message: 'Registration successful. Your account is active and ready to use.'
    });

  } catch (err: any) {

    if (err?.code === '23505') {
      return res.status(409).json({
        error: 'Username is unavailable'
      });
    }

    return next(err);
  }
});

/**
 * Public login endpoint.
 */
app.post('/api/auth/login', authLimiter, async (req, res, next) => {
  try {
    const input = loginSchema.parse(req.body);

    const result = await pool.query(
      `SELECT id, username, display_name, password_hash, role, status
       FROM users
       WHERE username = $1`,
      [input.username]
    );

    const user = result.rows[0];

    const valid = user
      ? await argon2.verify(user.password_hash, input.password).catch(() => false)
      : false;

    if (!user || !valid) {
      await audit(req, 'auth.login_failed', 'user', user?.id, {
        username: input.username
      });

      return res.status(401).json({
        error: 'Invalid username or password'
      });
    }

    if (user.status !== 'ACTIVE') {
      return res.status(403).json({
        error: 'Account is not active. Contact support.'
      });
    }

    req.session.regenerate(async err => {
      if (err) return next(err);

      req.session.userId = user.id;
      req.session.role = user.role;
      req.session.csrfToken = crypto.randomBytes(32).toString('hex');

      const csrfToken = req.session.csrfToken;

      req.session.save(async saveErr => {
        if (saveErr) return next(saveErr);

        try {
          await audit(req, 'auth.login_success', 'user', user.id, {
            role: user.role
          });

          return res.json({
            user: {
              id: user.id,
              username: user.username,
              displayName: user.display_name,
              role: user.role,
              status: user.status
            },
            csrfToken
          });
        } catch (auditErr) {
          return next(auditErr);
        }
      });
    });
  } catch (err) {
    return next(err);
  }
});

/**
 * Public session-check endpoint.
 *
 * Logged out: HTTP 200 { user: null }
 * Logged in:   HTTP 200 { user: {...} }
 */
app.get('/api/auth/me', async (req, res, next) => {
  try {
    if (!req.session.userId) {
      return res.status(200).json({ user: null });
    }

    const result = await pool.query(
      `SELECT id, username, display_name, role, status,
              parent_id, phone_number, commission_rate, created_at
       FROM users
       WHERE id = $1`,
      [req.session.userId]
    );

    const user = result.rows[0];

    if (!user || user.status !== 'ACTIVE') {
      return req.session.destroy(err => {
        if (err) return next(err);

        res.clearCookie(
          isProduction ? '__Host-mika.sid' : 'mika.sid',
          {
            httpOnly: true,
            secure: isProduction,
            sameSite: 'lax',
            path: '/'
          }
        );

        return res.status(200).json({ user: null });
      });
    }

    return res.status(200).json({ user });
  } catch (err) {
    return next(err);
  }
});

/**
 * Logout requires an authenticated session.
 */
app.post('/api/auth/logout', requireAuth, async (req, res, next) => {
  try {
    await audit(req, 'auth.logout', 'user', req.session.userId);

    req.session.destroy(err => {
      if (err) return next(err);

      res.clearCookie(
        isProduction ? '__Host-mika.sid' : 'mika.sid',
        {
          httpOnly: true,
          secure: isProduction,
          sameSite: 'lax',
          path: '/'
        }
      );

      return res.status(204).end();
    });
  } catch (err) {
    return next(err);
  }
});

/**
 * Change password requires an authenticated session.
 */
app.post('/api/auth/change-password', requireAuth, async (req, res, next) => {
  try {
    const input = z.object({
      currentPassword: z.string().min(1).max(64),
      newPassword: z.string().min(6).max(64)
    }).parse(req.body);

    const found = await pool.query(
      'SELECT password_hash FROM users WHERE id = $1 AND status = $2',
      [req.session.userId, 'ACTIVE']
    );

    if (
      !found.rowCount ||
      !(await argon2.verify(found.rows[0].password_hash, input.currentPassword))
    ) {
      return res.status(400).json({
        error: 'Current password is incorrect'
      });
    }

    const hash = await argon2.hash(input.newPassword, {
      type: argon2.argon2id,
      memoryCost: 19456,
      timeCost: 2,
      parallelism: 1
    });

    await pool.query(
      'UPDATE users SET password_hash = $1, updated_at = now() WHERE id = $2',
      [hash, req.session.userId]
    );

    await audit(req, 'auth.password_changed', 'user', req.session.userId);

    return res.json({
      message: 'Password changed'
    });
  } catch (err) {
    return next(err);
  }
});

/**
 * Private current-account endpoint.
 */
app.get('/api/accounts/me', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT u.id, u.username, u.display_name AS "displayName", u.role, u.status,
              u.parent_id AS "parentId", u.phone_number AS "phoneNumber",
              u.commission_rate AS "commissionRate", w.currency,
              w.balance_minor AS "balanceMinor", u.created_at AS "createdAt"
       FROM users u
       JOIN wallets w ON w.user_id = u.id
       WHERE u.id = $1`,
      [req.session.userId]
    );

    if (!result.rowCount) {
      return res.status(404).json({
        error: 'Account not found'
      });
    }

    return res.json({
      account: result.rows[0]
    });
  } catch (err) {
    return next(err);
  }
});

/**
 * List accounts within the user's permitted hierarchy.
 */
app.get('/api/accounts', requireRoles('ADMIN', 'SUPER_AGENT', 'AGENT'), async (req, res, next) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit) || 50, 1), 100);

    const query = `
      WITH RECURSIVE descendants AS (
        SELECT id FROM users WHERE parent_id = $1
        UNION ALL
        SELECT u.id
        FROM users u
        JOIN descendants d ON u.parent_id = d.id
      )
      SELECT u.id, u.username, u.display_name AS "displayName", u.role, u.status,
             u.parent_id AS "parentId", w.currency,
             w.balance_minor AS "balanceMinor", u.created_at AS "createdAt"
      FROM users u
      JOIN wallets w ON w.user_id = u.id
      WHERE ($2::boolean OR u.id IN (SELECT id FROM descendants))
      ORDER BY u.created_at DESC
      LIMIT $3`;

    const isAdmin = req.session.role === 'ADMIN';

    const result = await pool.query(
      query,
      [req.session.userId, isAdmin, limit]
    );

    return res.json({
      accounts: result.rows
    });
  } catch (err) {
    return next(err);
  }
});

/**
 * Admin-only user status management.
 */
app.post('/api/admin/users/:id/status', requireRoles('ADMIN'), async (req, res, next) => {
  try {
    const input = z.object({
      status: z.enum(['ACTIVE', 'SUSPENDED', 'CLOSED', 'PENDING'])
    }).parse(req.body);

    const updated = await pool.query(
      `UPDATE users
       SET status = $1, updated_at = now()
       WHERE id = $2
       RETURNING id, username, role, status`,
      [input.status, req.params.id]
    );

    if (!updated.rowCount) {
      return res.status(404).json({
        error: 'User not found'
      });
    }

    await audit(req, 'admin.user_status_changed', 'user', req.params.id, {
      status: input.status
    });

    return res.json({
      user: updated.rows[0]
    });
  } catch (err) {
    return next(err);
  }
});

/**
 * Wallet transfer endpoint.
 */
app.post('/api/wallet/transfer', requireAuth, async (req, res, next) => {
  try {
    if (config.ALLOW_PLAYER_TRANSFERS !== 'true') {
      return res.status(403).json({
        error: 'Transfers are disabled by policy'
      });
    }

    const input = transferSchema.parse(req.body);

    if (input.toUserId === req.session.userId) {
      return res.status(400).json({
        error: 'Cannot transfer to the same account'
      });
    }

    const idemKey = req.header('idempotency-key');

    if (!idemKey || idemKey.length > 128) {
      return res.status(400).json({
        error: 'A valid Idempotency-Key header is required'
      });
    }

    const tx = await transaction(async client => {
      const previous = await client.query(
        'SELECT id FROM ledger_transactions WHERE idempotency_key = $1',
        [idemKey]
      );

      if (previous.rowCount) {
        return {
          id: previous.rows[0].id,
          replay: true
        };
      }

      const ids = [req.session.userId!, input.toUserId].sort();

      const locked = await client.query(
        `SELECT user_id, currency, balance_minor
         FROM wallets
         WHERE user_id = ANY($1::uuid[])
         ORDER BY user_id
         FOR UPDATE`,
        [ids]
      );

      if (locked.rowCount !== 2) {
        throw Object.assign(new Error('Wallet not found'), { status: 404 });
      }

      const from = locked.rows.find(r => r.user_id === req.session.userId);
      const to = locked.rows.find(r => r.user_id === input.toUserId);

      if (!from || !to || from.currency !== input.currency || to.currency !== input.currency) {
        throw Object.assign(new Error('Currency mismatch'), { status: 400 });
      }

      if (BigInt(from.balance_minor) < BigInt(input.amountMinor)) {
        throw Object.assign(new Error('Insufficient balance'), { status: 409 });
      }

      const created = await client.query(
        `INSERT INTO ledger_transactions
          (transaction_type, idempotency_key, reference, description, created_by)
         VALUES ('TRANSFER', $1, $2, 'Wallet transfer', $3)
         RETURNING id`,
        [idemKey, input.reference ?? null, req.session.userId]
      );

      const transactionId = created.rows[0].id;

      await client.query(
        'UPDATE wallets SET balance_minor = balance_minor - $1, updated_at = now() WHERE user_id = $2',
        [input.amountMinor, req.session.userId]
      );

      await client.query(
        'UPDATE wallets SET balance_minor = balance_minor + $1, updated_at = now() WHERE user_id = $2',
        [input.amountMinor, input.toUserId]
      );

      await client.query(
        `INSERT INTO ledger_entries
          (transaction_id, user_id, amount_minor, currency)
         VALUES ($1, $2, $3, $4), ($1, $5, $6, $4)`,
        [
          transactionId,
          req.session.userId,
          -input.amountMinor,
          input.currency,
          input.toUserId,
          input.amountMinor
        ]
      );

      return {
        id: transactionId,
        replay: false
      };
    });

    await audit(req, 'wallet.transfer', 'ledger_transaction', tx.id, {
      replay: tx.replay
    });

    return res.status(tx.replay ? 200 : 201).json({
      transactionId: tx.id,
      replayed: tx.replay
    });
  } catch (err) {
    return next(err);
  }
});

/**
 * Bet debit request endpoint.
 * This records a debit request only; it does not settle bets or calculate outcomes.
 */
app.post('/api/bets', requireAuth, async (req, res, next) => {
  try {
    const input = betSchema.parse(req.body);
    const idemKey = req.header('idempotency-key');

    if (!idemKey || idemKey.length > 128) {
      return res.status(400).json({
        error: 'A valid Idempotency-Key header is required'
      });
    }

    const result = await transaction(async client => {
      const previous = await client.query(
        'SELECT id FROM ledger_transactions WHERE idempotency_key = $1',
        [idemKey]
      );

      if (previous.rowCount) {
        return {
          id: previous.rows[0].id,
          replay: true
        };
      }

      const wallet = await client.query(
        'SELECT currency, balance_minor FROM wallets WHERE user_id = $1 FOR UPDATE',
        [req.session.userId]
      );

      if (!wallet.rowCount) {
        throw Object.assign(new Error('Wallet not found'), { status: 404 });
      }

      if (BigInt(wallet.rows[0].balance_minor) < BigInt(input.amountMinor)) {
        throw Object.assign(new Error('Insufficient balance'), { status: 409 });
      }

      const created = await client.query(
        `INSERT INTO ledger_transactions
          (transaction_type, idempotency_key, reference, description, created_by)
         VALUES ('BET_DEBIT', $1, $2, $3, $4)
         RETURNING id`,
        [
          idemKey,
          input.externalBetId,
          `Bet debit: ${input.gameCode}`,
          req.session.userId
        ]
      );

      await client.query(
        'UPDATE wallets SET balance_minor = balance_minor - $1, updated_at = now() WHERE user_id = $2',
        [input.amountMinor, req.session.userId]
      );

      await client.query(
        `INSERT INTO ledger_entries
          (transaction_id, user_id, amount_minor, currency)
         VALUES ($1, $2, $3, $4)`,
        [
          created.rows[0].id,
          req.session.userId,
          -input.amountMinor,
          wallet.rows[0].currency
        ]
      );

      return {
        id: created.rows[0].id,
        replay: false
      };
    });

    await audit(req, 'bet.debit_requested', 'ledger_transaction', result.id, {
      gameCode: input.gameCode,
      replay: result.replay
    });

    return res.status(result.replay ? 200 : 201).json({
      transactionId: result.id,
      replayed: result.replay,
      note: 'Debit recorded only; outcome and settlement are not implemented.'
    });
  } catch (err) {
    return next(err);
  }
});

/**
 * Current user's ledger entries.
 */
app.get('/api/ledger/me', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT t.id AS "transactionId",
              t.transaction_type AS type,
              t.status,
              t.reference,
              t.description,
              e.amount_minor AS "amountMinor",
              e.currency,
              e.created_at AS "createdAt"
       FROM ledger_entries e
       JOIN ledger_transactions t ON t.id = e.transaction_id
       WHERE e.user_id = $1
       ORDER BY e.created_at DESC
       LIMIT 100`,
      [req.session.userId]
    );

    return res.json({
      entries: result.rows
    });
  } catch (err) {
    return next(err);
  }
});

/**
 * Admin-only audit log.
 */
app.get('/api/audit', requireRoles('ADMIN'), async (req, res, next) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 250);

    const result = await pool.query(
      `SELECT id,
              actor_user_id AS "actorUserId",
              action,
              target_type AS "targetType",
              target_id AS "targetId",
              ip_address AS "ipAddress",
              user_agent AS "userAgent",
              metadata,
              created_at AS "createdAt"
       FROM audit_events
       ORDER BY created_at DESC
       LIMIT $1`,
      [limit]
    );

    return res.json({
      events: result.rows
    });
  } catch (err) {
    return next(err);
  }
});

/**
 * Central error handler.
 */
app.use((
  err: any,
  _req: express.Request,
  res: express.Response,
  _next: express.NextFunction
) => {
  if (err instanceof z.ZodError) {
    return res.status(400).json({
      error: 'Invalid request',
      details: err.issues.map(i => ({
        path: i.path.join('.'),
        message: i.message
      }))
    });
  }

  if (err?.status && Number.isInteger(err.status)) {
    return res.status(err.status).json({
      error: err.message
    });
  }

  if (err?.code === '23505') {
    return res.status(409).json({
      error: 'Duplicate request'
    });
  }

  console.error('Unhandled API error:', err?.message ?? 'unknown error');

  return res.status(500).json({
    error: 'Internal server error'
  });
});

app.listen(config.PORT, () => {
  console.log(`Mika API listening on port ${config.PORT}`);
});