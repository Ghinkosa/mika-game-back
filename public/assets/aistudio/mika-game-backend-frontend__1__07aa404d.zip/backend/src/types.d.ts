import 'express-session';
declare module 'express-session' {
  interface SessionData {
    userId?: string;
    role?: 'ADMIN' | 'SUPER_AGENT' | 'AGENT' | 'PLAYER';
    csrfToken?: string;
  }
}
