# Backend structure

The PostgreSQL API currently boots from `src/server.ts`; database access/configuration/security primitives are in `src/db.ts`, `src/config.ts`, and `src/security.ts`. The module and SoftSwiss directories are established boundaries for the next extraction of route/controller/service/repository files. Existing behavior is retained rather than replaced with placeholder business logic.

Database schema: `database/migrations/`. Initial demo data: `src/seed.ts` (safe seed-if-empty behavior).
