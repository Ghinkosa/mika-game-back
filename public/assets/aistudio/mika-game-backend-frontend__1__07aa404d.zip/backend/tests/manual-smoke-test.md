# Manual smoke test checklist

- [ ] `GET /health` returns `{ "status": "ok" }`.
- [ ] `GET /api/auth/csrf` returns a CSRF token and sets a session cookie.
- [ ] Registration rejects short passwords and malformed usernames.
- [ ] Registration creates `PENDING` player + zero wallet; cannot log in until approved.
- [ ] Login rejects wrong passwords and non-active accounts.
- [ ] Login rotates session ID and returns a CSRF token.
- [ ] Unauthenticated `/api/accounts/me` returns 401.
- [ ] Authenticated POST without CSRF header returns 403.
- [ ] Player cannot call `/api/audit` or admin status endpoint.
- [ ] Transfer endpoint rejects when transfers are disabled.
- [ ] With transfers enabled for test only: insufficient balance fails; successful transfer creates two equal-and-opposite ledger entries and updates balances atomically.
- [ ] Repeating same idempotency key does not duplicate a transfer.
- [ ] Audit records contain no password, cookie, CSRF token, or session ID.
- [ ] Production deployment uses HTTPS, secure cookies, least-privilege DB role, and a secret manager.
